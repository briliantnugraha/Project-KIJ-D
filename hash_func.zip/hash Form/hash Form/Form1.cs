﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace hash_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String inp = inputText.Text;
            byte[] hash;
            label2.Text = inp;

            var gotobyte = Encoding.UTF8.GetBytes(inp);
            SHA512 manage = new SHA512Managed();

            hash = manage.ComputeHash(gotobyte);
            String outputHash = BitConverter.ToString(hash);
            outputText.Text = outputHash; 
            
        }
    }
}
